# Financial NIZAM Master Index

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** PFOS v1.3 FINAL; artifacts 01--22

## What this governs

Canonical navigation, read order, package status, supersession,
sensitivity, and validation state.

## What this does not govern

Runtime balances, implementation paths not verified in the current
repository, or authority to move money.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Read first

Future agents MUST read in this order: this index → PFOS v1.3 FINAL →
`01_FINANCIAL_NIZAM_CONSTITUTION_AND_TENETS.md` →
`03_FINANCIAL_NIZAM_DATA_MODEL_AND_CONTRACTS.md` → the domain document
relevant to the task → `16_FINANCIAL_NIZAM_VALIDATION_TESTS.md` →
`20_FINANCIAL_NIZAM_AGENT_RUNBOOK.md`.

## Domain map

  Domain                        Canonical package artifact
  ----------------------------- ----------------------------
  Governance                    01, 22
  Lineage/research              02, 21
  Data/contracts                03, 13
  Transactions/reconciliation   04, 05
  Budget/debt                   06, 07
  Liquidity/forecast            08, 09
  Monitoring/decisions          10, 11
  Agents/privacy                12, 14
  UX                            15
  Validation/roadmap            16, 17
  Runtime templates             18, 19, 20

## Supersession rule

This package does not supersede PFOS v1.3 FINAL. It decomposes its
financial requirements into operational subordinate contracts. Any
conflict is resolved upward, recorded in artifact 22, and never silently
patched.

## Sensitivity

The package contains architecture and synthetic schemas only and is
`review_before_commit`. Runtime ledgers, balances, statements, debts,
income, personal decision records, and raw transaction evidence remain
`strict_local` unless an owning policy explicitly states otherwise.

## Open gaps

`CONTRACT_4_ui_ynab.md`, the post-YNAB live-product teardown, current
repository implementation state, and runtime acceptance-test output
remain unresolved.
