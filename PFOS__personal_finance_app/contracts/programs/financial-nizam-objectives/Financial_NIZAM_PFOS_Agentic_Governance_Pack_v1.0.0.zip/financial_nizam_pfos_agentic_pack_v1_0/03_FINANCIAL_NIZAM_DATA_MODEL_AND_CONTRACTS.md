# Financial NIZAM Data Model and Contracts

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 01, 13

## What this governs

Canonical finance entities, field semantics, provenance, status,
versioning, and compatibility.

## What this does not govern

Database-vendor choice or unverified physical table names.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Global invariants

All authoritative monetary values MUST be integer milliunits with
explicit currency. IDs are stable and opaque. All mutable business
records expose `created_at`, `updated_at`, source provenance, and audit
linkage. Historical corrections are versioned/superseding rather than
destructive.

## Canonical entities

### Account

`account_id, institution, account_type, display_name, currency, status, statement_cycle, balance_type, last_reconciled_at, source_ids, sensitivity`

### Transaction

`transaction_id, account_id, source_record_id, source_type, source_timestamp, posted_at, effective_at, status, amount_milliunits, currency, direction, merchant_raw, merchant_normalized, description_raw, category_id, category_confidence, transaction_type, transfer_pair_id, parent_transaction_id, evidence_ref, dedupe_fingerprint, reconciliation_status, manual_override, created_at, updated_at`

### BudgetCategory

`category_id, group_id, name, type, priority, monthly_target_milliunits, target_type, rollover_policy, overspend_policy, currency, active`

### BudgetPeriod

`period_id, start_date, end_date, currency, income_available_milliunits, assigned_milliunits, unassigned_milliunits, actual_spend_milliunits, carry_forward_milliunits, status`

### Obligation

`obligation_id, type, counterparty, currency, principal_or_remaining_balance_milliunits, minimum_due_milliunits, due_date_or_rule, frequency, interest_or_fee_policy_ref, penalty_risk, autopay, priority, source_ref, status`

### IncomeEvent

`income_id, source, expected_date, expected_amount_milliunits, currency, confidence, recurrence, actual_transaction_id, status`

### ForecastItem

`forecast_item_id, type, date_or_range, amount_or_distribution_ref, currency, scenario, confidence, assumption_ref, source_ref`

### FinancialSnapshot

`snapshot_id, as_of, account_balance_refs, available_cash_ref, reserved_cash_ref, credit_due_ref, total_debt_ref, next_7d_outflow_ref, next_30d_outflow_ref, expected_income_ref, budget_available_ref, liquidity_buffer_ref, forecast_summary, unresolved_items, calculation_version, policy_version`

### DecisionRecord

`decision_id, question, options, hard_constraints, inputs, scoring_ref, recommended_option, counterargument, confidence, user_decision, effective_date, review_date, evidence_refs`

### Alert

`alert_id, type, severity, trigger_rule, detected_at, impact_ref, confidence, evidence_refs, recommended_action, status, snooze_until, resolved_at`

### EvidenceRecord

`evidence_id, source_type, source_location, ingested_at, period_start, period_end, hash_or_fingerprint, parser_version, sensitivity, quality_status`

### AuditEvent

`audit_event_id, timestamp, actor, action, entity_type, entity_id, before_ref, after_ref, reason, evidence_refs, approval_ref`

### Merchant

`merchant_id, canonical_name, aliases, default_category, category_confidence, country, merchant_type, user_rules`

### FinancialGoal

`goal_id, name, goal_type, target_amount_milliunits, currency, target_date, priority, current_progress_ref, funding_rule, status`

## Common enums

`EvidenceClass = FACT | USER_REPORT | COMPUTED | INFERENCE | HYPOTHESIS | UNKNOWN`\
`ReconciliationStatus = UNSEEN | INGESTED | NORMALIZED | MATCHED | RECONCILED | EXCEPTION | MANUALLY_RESOLVED`\
`TransactionStatus = PENDING | POSTED | REVERSED | VOID`\
`Sensitivity = strict_local | strict_local_maximum | review_before_commit | private_github`

## Synthetic JSON example

``` json
{
  "transaction_id": "txn_SYNTH_001",
  "account_id": "acct_SYNTH_A",
  "source_record_id": "provider_SYNTH_77",
  "status": "POSTED",
  "amount_milliunits": 125000,
  "currency": "EGP",
  "direction": "OUTFLOW",
  "merchant_raw": "SYNTHETIC MERCHANT",
  "merchant_normalized": "Synthetic Merchant",
  "reconciliation_status": "RECONCILED",
  "evidence_ref": "ev_SYNTH_1",
  "manual_override": false
}
```

The numeric value above is synthetic test data, not a user financial
value.

## Compatibility rule

No dependent document may invent a second definition of Account,
Transaction, BudgetCategory, BudgetPeriod, Obligation, IncomeEvent,
ForecastItem, FinancialSnapshot, DecisionRecord, Alert, EvidenceRecord,
AuditEvent, Merchant, or FinancialGoal.
