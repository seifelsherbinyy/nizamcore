# Financial NIZAM Transaction Ingestion and Forensics

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 05, 13, 16

## What this governs

Evidence registration, parsing, normalization, transaction identity,
dedupe, classification, and exception handling.

## What this does not govern

Balance truth before reconciliation or provider-specific parsing rules
not verified for that provider.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Pipeline

`RAW EVIDENCE → EVIDENCE RECORD → PARSE → NORMALIZE → IDENTITY/DEDUPE → RELATION MATCHING → CLASSIFICATION → LEDGER CANDIDATE → RECONCILIATION → AUDIT`

Raw evidence SHOULD be immutable or content-addressed. Normalized
corrections MUST preserve raw values.

## Identity and dedupe

Prefer provider transaction IDs within institution/account scope. A
fallback fingerprint MUST combine stable source fields and MUST NOT
deduplicate solely on amount/date. Re-importing identical evidence MUST
be idempotent.

## Edge-case rules

-   Pending and posted forms are related states; actual spending counts
    the posted canonical state once.
-   Bank-to-card payments and internal account transfers are transfers,
    not new spending/income.
-   Refunds, reversals, and chargebacks retain links to originals where
    possible.
-   Installments represent purchase economics plus liability/payment
    schedule without double counting.
-   Cash withdrawal is a transfer to cash until downstream cash use is
    evidenced or intentionally expensed.
-   Split children MUST equal the parent under deterministic precision
    rules.
-   FX preserves original and settlement currency, provider rate/date
    when available, and fees.
-   Interest and fees are explicit expense types.
-   Unknown/low-confidence categories enter review rather than forced
    classification.
-   Manual corrections outrank inference and remain auditable.

## Categorization order

Explicit user rule → verified merchant mapping → high-confidence
historical pattern → statement metadata → model suggestion →
UNKNOWN/REVIEW.

## Forensic exception queue

Each exception records type, affected evidence/transactions,
materiality, current hypothesis, conflicting evidence, next evidence
needed, owner, age, and resolution status.
