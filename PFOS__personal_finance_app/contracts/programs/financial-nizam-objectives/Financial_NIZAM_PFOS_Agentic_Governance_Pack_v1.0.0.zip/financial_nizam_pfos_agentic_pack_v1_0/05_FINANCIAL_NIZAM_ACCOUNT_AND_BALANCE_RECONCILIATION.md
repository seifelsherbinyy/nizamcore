# Financial NIZAM Account and Balance Reconciliation

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 04, 07, 16

## What this governs

Trust establishment for account balances, statement cycles, card states,
and mismatch resolution.

## What this does not govern

Optimization from unreconciled balances.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Balance concepts

Opening balance, statement balance, current balance, available balance,
available credit, amount due, minimum due, pending value, and reconciled
ledger balance are distinct fields. Credit availability MUST NOT be
treated as cash or net worth.

## Reconciliation workflow

1.  Register authoritative balance/statement evidence with as-of time.
2.  Confirm account identity and statement period.
3.  Match normalized transactions to source records.
4.  Apply pending/posted/reversal rules.
5.  Recompute deterministic ledger balance.
6.  Compare to authoritative assertion using currency-specific
    exact/tolerance policy.
7.  If mismatch remains, open an exception; never average competing
    balances.
8.  Close only with evidence and an audit event.

## Credit cards

Statement balance, total/current balance, minimum due, due date,
interest/fees, payments, refunds, and pending items MUST remain
distinguishable. A payment reduces the liability but is not a second
expense.

## Unreconciled behavior

Material recommendations MUST disclose unreconciled status and may
narrow horizon, request evidence, or withhold a monetary verdict. A
stale but historically correct balance MUST NOT be represented as
current.
