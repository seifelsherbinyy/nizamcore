# Financial NIZAM Budgeting System

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 05, 07, 19

## What this governs

PFOS-native envelope allocation, category availability, rollover,
overspending, sinking funds, and budget-to-actual reconciliation.

## What this does not govern

Forecast cash as actual budget money or silently changing user
priorities.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Core semantics

Actual budgeting assigns money already available in the canonical
reconciled state. Forecast allocation is a separate view and MUST be
labeled forecast-only. Budget targets are intentions, not obligations.

## Category groups

Fixed obligations; essential variable spending; debt service;
liquidity/emergency buffer; sinking funds; goals/savings; discretionary
lifestyle; travel/events; gifts/family; professional/education;
unassigned/contingency.

## Allocation rules

Each category defines purpose, priority, target rule, rollover policy,
overspend policy, currency, and active state. Income arrival MAY trigger
an assignment proposal. The system MUST show the tradeoff when moving
allocation between categories.

## Rollover and overspending

Rollover is category-specific. Overspending remains visible and creates
reallocation options from lower-priority categories; it MUST NOT be
hidden by rewriting history. Changing a target affects future planning,
not historical allocations.

## Reimbursements/shared expenses

Reimbursements MUST link to the original expense/category policy and
MUST NOT inflate ordinary income. Shared expenses preserve gross
transaction evidence and a separate expected reimbursement claim if
applicable.

## Sinking funds

Sinking-fund allocation is reserved availability for a known irregular
purpose, not an expense until the actual transaction occurs.

## Monthly budget close

Reconcile canonical transactions → finalize classifications → calculate
actuals → apply approved rollover → expose variance as
timing/structural/exception → record allocation changes → seed
next-period proposals.
