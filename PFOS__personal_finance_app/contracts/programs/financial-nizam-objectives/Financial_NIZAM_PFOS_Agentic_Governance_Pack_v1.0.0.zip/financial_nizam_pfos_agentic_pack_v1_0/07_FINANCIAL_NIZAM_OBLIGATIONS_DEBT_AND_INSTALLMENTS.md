# Financial NIZAM Obligations, Debt and Installments

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 05, 08, 11, 14

## What this governs

Liability registry, due-date protection, installment schedules, debt
strategy inputs, and approval gates.

## What this does not govern

Executing repayment, restructuring, borrowing, or provider-specific
legal conclusions.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## First-class obligation types

Credit card, installment plan, personal loan, family loan, subscription,
utility/bill, housing, insurance, education, tax/government payment,
contractual payment, and informal commitment.

## Required state

Each obligation stores counterparty, type, currency, remaining-balance
engine reference, next due engine reference, due rule, minimum required,
frequency, cost/fee policy reference, penalty risk, autopay state,
priority, evidence, confidence, and status.

## Priority policy

Avoid delinquency/contractual penalty → preserve required minimums →
protect near-term liquidity → compare incremental payoff using
deterministic cost and cash-flow effects → incorporate explicit
relational/ethical/user constraints.

## Installments

The purchase event and financing obligation are linked. Scheduled
payments reduce liability according to deterministic engine rules. The
system MUST prevent purchase-plus-payment double counting.

## Strategy boundary

PFOS may model alternatives and produce evidence packages. It MUST NOT
execute payment, refinancing, restructuring, borrowing, cancellation, or
account changes. Those remain human-controlled.
