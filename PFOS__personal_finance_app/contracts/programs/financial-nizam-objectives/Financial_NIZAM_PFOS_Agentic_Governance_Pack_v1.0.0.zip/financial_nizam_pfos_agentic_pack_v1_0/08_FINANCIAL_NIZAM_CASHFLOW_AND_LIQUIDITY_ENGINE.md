# Financial NIZAM Cashflow and Liquidity Engine

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 05, 07, 09, 11

## What this governs

Definitions and deterministic inputs for present liquidity and near-term
cash timing.

## What this does not govern

LLM calculation of money or treating expected income as present cash.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Definitions

`gross_cash`: engine-produced total cash-like balances before
reservations.\
`reserved_cash`: engine-produced protected allocations for imminent
obligations/buffers.\
`available_cash`: engine-produced currently accessible cash, excluding
forecast income.\
`net_operational_liquidity`: deterministic available cash less committed
outflows for a defined horizon.\
`safe_to_spend`: deterministic decision metric returned by PFOS, never
inferred from bank balance alone.

## Horizons

Today, 7 days, 14 days, 30 days, and 90 days. Each result carries
snapshot ID, policy version, currency, freshness, and confidence/quality
state.

## Timeline order

Opening available cash → known income → expected income (separate) →
fixed obligations → debt minimums → planned commitments → estimated
variable essentials → buffer reservations → uncertainty reserve →
projected closing state.

## Failure behavior

If a material account is stale/unreconciled, the engine returns a
limited/unknown state rather than false precision. Expected income MUST
NOT be labeled current liquidity.
