# Financial NIZAM Forecasting and Scenario Engine

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 08, 13, 16

## What this governs

Versioned forecast assumptions, scenarios, uncertainty, error tracking,
and sensitivity.

## What this does not govern

Guarantees or spending authority based on unreceived income.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Horizons and scenarios

Operational: 7 days. Planning: 30 and 90 days. Strategic: up to 12
months only when evidence supports it. Scenarios: base, downside,
upside, and user-defined event.

## Input hierarchy

Known balances and contracted obligations → dated planned events →
recurring items supported by history → uncertain income/expenses →
statistical estimates. Known dated items MUST precede averages.

## Forecast object

Every forecast records version, snapshot ID, horizon, scenario,
assumptions, source refs, uncertainty representation, calculation
version, generated time, and confidence.

## Learning

Forecast-vs-actual error is persisted by item type and horizon. High
error or stale evidence lowers confidence and widens deterministic
ranges rather than manufacturing precision.

## Sensitivity

When one or two assumptions dominate outcome, the engine SHOULD produce
a sensitivity result identifying the driver and the direction of impact.
The conversational layer explains the engine result but does not compute
it.
