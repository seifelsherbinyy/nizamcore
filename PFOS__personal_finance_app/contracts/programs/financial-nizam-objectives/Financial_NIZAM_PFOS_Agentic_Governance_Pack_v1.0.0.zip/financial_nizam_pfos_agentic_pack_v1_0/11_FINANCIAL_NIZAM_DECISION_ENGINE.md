# Financial NIZAM Decision Engine

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 01, 07, 08, 09, 14

## What this governs

Evidence-based tradeoff analysis for spending, debt, buffer, savings,
and competing uses of cash.

## What this does not govern

Executing the decision or fabricating monetary comparisons.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Required dimensions

Urgency, liquidity impact, deterministic effective-cost result,
penalty/default risk, reversibility, cash-flow timing, goal alignment,
option value, uncertainty, complexity/stress cost, and explicit user
constraints.

## Material decision packet

Decision question; FACTS; MISSING/UNKNOWN; options; hard constraints;
deterministic quantitative comparison reference; base recommendation;
strongest counterargument; scenario sensitivity; confidence; evidence
that could change the result; approval class.

## Hard gates

No recommendation for borrowing, refinancing, early payoff, liquidation,
or major discretionary spending may bypass liquidity/obligation
modeling. Interest rate alone MUST NOT define debt priority.
Provider/regulatory claims require fresh authoritative research.

## Close numerical calls

If deterministic differences are immaterial or uncertain, explain
qualitative tradeoffs rather than claiming false precision. `optimal` is
prohibited unless objective and constraints are explicit.

## Human decision

`user_decision` remains unset until the human actually decides. The
agent may recommend but MUST NOT mark `Decision Made?`.
