# Financial NIZAM Agent Roles and Orchestration

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 01, 03, 13, 14, 20

## What this governs

Role boundaries, shared state, handoffs, permissions, and orchestration
order.

## What this does not govern

Creating independent competing financial truth systems.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Roles

  ------------------------------------------------------------------------------------
  Role                    Owns                               Must not
  ----------------------- ---------------------------------- -------------------------
  Finance Orchestrator    dependency order and synthesis     bypass
                                                             reconciliation/approval

  Evidence Ingestion      retrieval, provenance, parsing     recommend strategy
  Agent                                                      

  Reconciliation Agent    identity, matching, mismatch queue invent transactions

  Budget Agent            allocations/rollovers/variance     budget future income as
                                                             actual

  Obligation & Debt Agent due state and risk                 restructure/commit funds

  Cashflow & Forecast     timelines/scenarios/error          present scenarios as
  Agent                                                      guarantees

  Monitoring Agent        checks/alerts/cooldowns            execute payments or spam

  Decision Agent          tradeoff recommendation            override constraints

  Research Agent          fresh provider/regulatory          promote anecdotes to
                          verification                       policy

  Privacy & Approval Gate sensitivity/egress/authority       expose unnecessary raw
                                                             data

  Audit Agent             invariants/provenance/regression   mutate state outside
                                                             repair workflow
  ------------------------------------------------------------------------------------

## Handoff schema

`task_id, request, input_artifacts, canonical_state_version, assumptions, unresolved_items, expected_output, write_permissions, approval_required, completion_status, audit_refs`

## Orchestration order

Evidence retrieval → quality check → normalization → reconciliation →
canonical-state rebuild → budget/obligation update → forecast →
monitoring → decision analysis → approval gate → writeback → audit
validation → session handover.

## Single-writer rule

Temporary/sub-agents MAY analyze but MUST write only through the
authoritative port. UI, LLM, Telegram, and temporary agents MUST NOT
directly mutate canonical finance tables/ledgers.
