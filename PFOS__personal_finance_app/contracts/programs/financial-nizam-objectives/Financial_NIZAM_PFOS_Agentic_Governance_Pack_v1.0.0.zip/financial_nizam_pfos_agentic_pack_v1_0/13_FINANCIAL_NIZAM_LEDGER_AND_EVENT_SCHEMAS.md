# Financial NIZAM Ledger and Event Schemas

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 04, 10, 22

## What this governs

Durable append/audit ledgers for financial state transitions and agent
actions.

## What this does not govern

Raw secret storage or provider credentials.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Required ledgers

Transaction; account snapshot; obligation; budget allocation; budget
variance; forecast; decision; alert; manual correction; source
ingestion; agent action; model/inference.

## Common event envelope

``` json
{
  "event_id": "evt_SYNTH_001",
  "event_type": "BUDGET_ALLOCATION_CHANGED",
  "occurred_at": "2026-09-15T20:00:00+03:00",
  "actor": "SYNTHETIC_TEST_ACTOR",
  "entity_type": "BudgetCategory",
  "entity_id": "cat_SYNTH_1",
  "source_refs": ["ev_SYNTH_1"],
  "policy_version": "policy_SYNTH_1",
  "schema_version": "1.0.0",
  "reason": "synthetic fixture",
  "supersedes_event_id": null,
  "sensitivity": "strict_local"
}
```

## Mutation rule

Corrections append an event that references the prior event/record.
Historical events do not disappear. Model inference is logged separately
from deterministic state.

## Audit minimum

Caller, action, target, timestamp, source/evidence refs, schema/policy
version, before/after references where applicable, approval reference,
result, and receipt.
