# Financial NIZAM UI and User Journeys

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 10, 11, 14

## What this governs

Decision-centered finance surfaces, trust cues, transaction inbox,
reviews, and conversational flows.

## What this does not govern

Making dashboard presentation authoritative over PFOS calculations.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Ten-second comprehension

Primary surface SHOULD answer: current reliability/status; what is safe
to spend (engine result); next protected obligation; what changed;
whether trajectory is improving; highest-priority action; effect of a
contemplated decision.

## Primary views

Home financial state; safe-to-spend; upcoming obligations; budget;
cash-flow timeline; debt; alerts; scenarios; transaction inbox; unknown
resolution; monthly review; decision cards.

## Trust cues

Every material value shows currency, as-of/freshness, reconciliation
state, source/provenance affordance, and policy/calculation version
where useful. Color is never the only status signal.

## Transaction inbox

Unknown, duplicate-suspect, transfer-unmatched, low-confidence category,
reversal/refund, and reconciliation exceptions are resolvable with
explicit reason and audit trail.

## Conversational flow

Direct conclusion → deterministic status/value reference → why → impact
→ next action → optional evidence. Ask one high-information question
when a missing fact materially changes the answer.

## Accessibility/localization

English/Arabic ready, RTL compatible, keyboard/screen-reader aware,
mobile-first, and free of guilt-inducing dark patterns.
