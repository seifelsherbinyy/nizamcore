# Financial NIZAM Monthly Close Template

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 03, 06, 09, 13, 18

## What this governs

Repeatable evidence-based month close and carry-forward review.

## What this does not govern

Provider statement generation or silent policy changes.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Close checklist

Confirm expected source periods → reconcile accounts to authoritative
evidence → resolve/carry high-impact exceptions → finalize
classifications → compute income/spending through deterministic engine →
reconcile budget actuals → record debt/liquidity movement refs → record
fees/interest refs → compare forecast vs actual → record unusual
events/decisions → propose assumption updates under policy → generate
next-period obligations/allocation proposals → publish versioned close.

## Close record

``` yaml
monthly_close:
  period: <YYYY-MM>
  closed_at: <timestamp>
  source_completeness: <status>
  reconciliation: <status>
  income_ref: <engine-output>
  spending_ref: <engine-output>
  budget_variance_ref: <engine-output>
  debt_change_ref: <engine-output>
  liquidity_change_ref: <engine-output>
  fees_interest_ref: <engine-output>
  forecast_error_ref: <engine-output>
  unusual_events: []
  unresolved_items: []
  approved_rule_changes: []
  next_period_allocation_proposals: []
  audit_refs: []
```

The close is immutable/versioned; later corrections create a successor
close with provenance.
