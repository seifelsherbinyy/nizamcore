# Financial NIZAM Agent Runbook

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 00, 12, 14, 16, 18

## What this governs

Operational sequence for future semi-autonomous finance sessions.

## What this does not govern

Bypassing privacy, reconciliation, human authority, or repository RPV.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Session start

Identify request, lane, canonical-state version, required sources,
sensitivity, and whether current monetary truth is needed. Retrieve the
minimum relevant context.

## Operational loop

1.  Refresh/register evidence.
2.  Check quality/freshness.
3.  Normalize/dedupe.
4.  Reconcile.
5.  Rebuild canonical snapshot.
6.  Update budget/obligation derived state.
7.  Update forecast.
8.  Run monitoring.
9.  Produce at most a few high-impact recommendations.
10. Apply approval gate.
11. Write only through authoritative ports.
12. Append audit events.
13. Verify resulting state.
14. THABAT closeout.

## Failure recovery

Canonical source unavailable → mark provisional. Conflicting balances →
exception, never average. Missing category → UNKNOWN. Transfer ambiguity
→ hold unresolved. Forecast insufficient → narrow horizon/widen
uncertainty. Tool write unavailable → produce file-ready artifact and
receipt `FAILED`/`NOT_SYNCED` as appropriate.

## RPV

Any build/edit/schema/script/ledger/Drive write follows RESEARCH →
agreed PLAN → IMPLEMENT → VERIFY including tamper → RECORD/read-back.
