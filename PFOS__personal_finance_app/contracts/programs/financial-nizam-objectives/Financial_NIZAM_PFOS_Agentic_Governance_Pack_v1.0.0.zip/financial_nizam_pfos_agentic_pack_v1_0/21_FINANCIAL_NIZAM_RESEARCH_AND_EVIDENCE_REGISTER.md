# Financial NIZAM Research and Evidence Register

**Status:** CANONICAL CANDIDATE --- architecture package; implementation
remains unverified\
**Version:** 1.0.0\
**Owner/System:** Financial NIZAM / PFOS (MAL implementation namespace)\
**Sensitivity:** review_before_commit; synthetic/redacted examples only\
**Canonical marker:** Subordinate to PFOS v1.3 FINAL; becomes
operational only after repository integration and verification\
**Last validated:** 2026-09-15

**Dependencies:** 02, 15, 22

## What this governs

Durable separation of external evidence from internal architectural
decisions.

## What this does not govern

Turning community anecdotes into authoritative financial/provider
policy.

## Source lineage

This package is subordinate to
`NIZAM_PFOS_MASTER_UNIFIED_CONTRACT_v1.3_FINAL_DRIVE_SAFE` and the
canonical LOCAL_FULL sibling when they differ. It incorporates the
approved 2026-09-15 Financial NIZAM/PFOS build contract, the PFOS
four-blueprint architecture, MAL/PFA lineage, YNAB-inspired budgeting
research, transaction-forensics work, and the current NIZAM
router/privacy rules.

**Precedence:** safety/platform policy → newest explicit owner direction
→ PFOS v1.3 FINAL → non-conflicting owning subordinate contract →
verified runtime evidence → historical/draft material.

**Unresolved source search:** `CONTRACT_4_ui_ynab.md` and the post-YNAB
live-product teardown were not verified in the accessible corpus during
this build and MUST NOT be reconstructed from memory.

## Evidence tiers

E1 official/primary; E2 systematic/professional synthesis; E3 reputable
secondary; E4 expert commentary; E5 community/social; E6 unverified
anecdote. Current law, provider terms, finance rules, software
capability, and macro data require freshness tracking.

## Register

  -----------------------------------------------------------------------------------------------------------
  Claim / question           Source class        Finding               Architecture            Confidence
                                                                       implication             
  -------------------------- ------------------- --------------------- ----------------------- --------------
  Actual budget allocation   E1 product          YNAB's current guides PFOS keeps actual       HIGH
  should distinguish money   documentation       explicitly teach      allocation separate     
  currently available from   (YNAB)              assigning money       from forecast           
  future anticipated income                      currently held and    allocation              
                                                 separating budgeting                          
                                                 from anticipated                              
                                                 future income                                 

  Provider transaction       E1 technical        FITID exists to       Prefer provider IDs;    HIGH
  identifiers are stronger   specification       uniquely identify     composite fallback only 
  dedupe keys than           (OFX/FDX)           statement                                     
  amount/date alone                              transactions and                              
                                                 detect duplicate                              
                                                 downloads within                              
                                                 account/FI scope                              

  Audit records should       E1 government       NIST audit-control    AuditEvent envelope and HIGH
  preserve event             security guidance   guidance specifies    tamper-resistant        
  type/time/source/outcome   (NIST)              core event fields and retention are required  
  and be protected                               audit protection                              

  Exact bank/card/BNPL       RESEARCH_REQUIRED   Not encoded in this   Research per            UNRESOLVED
  behavior in Egypt                              package without       provider/jurisdiction   
                                                 current               before policy           
                                                 provider/regulatory                           
                                                 evidence                                      

  Missing                    INTERNAL SOURCE     Not verified in       Do not invent; keep gap UNRESOLVED
  `CONTRACT_4_ui_ynab.md`    SEARCH              accessible corpus     open                    

  Missing post-YNAB          INTERNAL SOURCE     Not verified in       Do not invent; keep gap UNRESOLVED
  live-product teardown      SEARCH              accessible corpus     open                    
  -----------------------------------------------------------------------------------------------------------

## Research object

Each future row SHOULD record claim, research question, source, source
class, publication/current date, retrieval date, finding, limitations,
confidence, architecture implication, contradictory sources, and review
date.
